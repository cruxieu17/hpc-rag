#!/usr/bin/env python3
"""
HPC-RAG Pipeline Main Execution Script
======================================

This script orchestrates the complete HPC-RAG pipeline execution:
1. Downloads and initializes required models
2. Sets up Qdrant vector database
3. Performs retrieval and reranking
4. Generates answers using LLM
5. Evaluates results using multiple metrics
6. Computes and displays final scores

Instructions:
1. Create a file named .env
```
OPENAI_API_KEY = abc
CHROMA_PERSIST_DIRECTORY = ./chroma_db
CHROMA_COLLECTION_NAME = text_embeddings
```

2. Run the code with `python baseline_rag_frontier.py`

Author: Auto-generated pipeline orchestrator
Date: 2025-10-04
"""

import os
import sys
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional
import subprocess
from transformers import AutoTokenizer, AutoModel, AutoModelForSequenceClassification
from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv  
load_dotenv()

# OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
# QDRANT_URL = os.getenv("QDRANT_URL")
# QDRANT_API_KEY = os.getenv("QDRANT_API_KEY")
# QDRANT_COLLECTION_NAME = os.getenv("QDRANT_COLLECTION_NAME")

# ============================================================================
# LOGGING CONFIGURATION
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('pipeline_execution.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


# ============================================================================
# CONFIGURATION
# ============================================================================

class PipelineConfig:
    """
    Configuration class for the RAG pipeline.
    Update these values according to your environment.
    """
    
    # ChromaDB Configuration
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    CHROMA_PERSIST_DIRECTORY: str = os.getenv("CHROMA_PERSIST_DIRECTORY", "./chroma_db")
    CHROMA_COLLECTION_NAME: str = os.getenv("CHROMA_COLLECTION_NAME", "text_embeddings")
    
    # Model Names (for local execution)

    EMBEDDING_MODEL: str = "mixedbread-ai/mxbai-embed-large-v1"
    RERANK_MODEL: str = "mixedbread-ai/mxbai-rerank-large-v1"
    GENERATION_MODEL: str = "meta-llama/Llama-3.1-8B-Instruct"
    BART_MODEL: str = "facebook/bart-large-cnn"
    BERT_MODEL: str = "bert-base-uncased"
    
    # Data Paths (relative to project root)
    PROJECT_ROOT: Path = Path(__file__).parent.absolute()
    DATA_DIR: Path = PROJECT_ROOT / "data"
    BASELINE_DIR: Path = PROJECT_ROOT / "baseline"
    
    # Data Files
    EXTRACTED_CHUNKS: Path = DATA_DIR / "extracted_chunks.json"
    TEXT_QNA: Path = DATA_DIR / "text_qna.json"
    TABLE_QNA: Path = DATA_DIR / "table_qna.json"
    TEXT_QNA_RETRIEVED: Path = DATA_DIR / "text_qna_retrieved_new.json"
    TABLE_QNA_RETRIEVED: Path = DATA_DIR / "table_qna_retrieved_new.json"
    TEXT_QNA_GENERATED: Path = DATA_DIR / "text_qna_generated_llama_new.json"
    TABLE_QNA_GENERATED: Path = DATA_DIR / "table_qna_generated_llama_new.json"
    TEXT_QNA_SCORED: Path = DATA_DIR / "text_qna_generated_llama_scored_new.json"
    TABLE_QNA_SCORED: Path = DATA_DIR / "table_qna_generated_llama_scored_new.json"
    TABLE_QNA_EVALUATED: Path = DATA_DIR / "table_qna_generated_llama_scored_evaluated_new.json"
    
    # Pipeline Control Flags
    USE_LOCAL_MODELS: bool = True  # Set to True to use local models for embedding/reranking (False = use API)
    SKIP_CHROMA_UPSERT: bool = False  # Set to True if data is already in ChromaDB
    SKIP_RETRIEVAL: bool = False  # Set to True if retrieval is already done
    SKIP_GENERATION: bool = False  # Set to True if generation is already done (always uses local model)
    SKIP_EVALUATION: bool = False  # Set to True if you want to skip evaluation
    FORCE_REGENERATE: bool = True  # Set to False to skip stages if output files already exist
    
    # Retrieval Parameters
    RETRIEVAL_TOP_K: int = 10  # Number of chunks to retrieve
    RERANK_TOP_K: int = 5  # Number of chunks after reranking
    
    # GPU/Device Configuration
    DEVICE: str = "mps"  # "cuda" or "cpu"


config = PipelineConfig()

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def check_file_exists(filepath: Path, required: bool = True) -> bool:
    """
    Check if a file exists. Optionally exit if required file is missing.
    
    Args:
        filepath: Path to the file
        required: If True, exit if file doesn't exist
    
    Returns:
        bool: True if file exists, False otherwise
    """
    exists = filepath.exists()
    if not exists and required:
        logger.error(f"Required file not found: {filepath}")
        logger.error("Please ensure all data files are present in the data/ directory")
        sys.exit(1)
    return exists


def load_json(filepath: Path) -> List[Dict]:
    """
    Load JSON data from a file.
    
    Args:
        filepath: Path to JSON file
    
    Returns:
        List of dictionaries containing the data
    """
    logger.info(f"Loading data from {filepath}")
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_json(data: List[Dict], filepath: Path) -> None:
    """
    Save data to a JSON file.
    
    Args:
        data: List of dictionaries to save
        filepath: Path to output JSON file
    """
    logger.info(f"Saving data to {filepath}")
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)


def check_environment() -> None:
    """
    Check if the environment is properly set up.
    Verifies Python version, required directories, and data files.
    """
    logger.info("=" * 70)
    logger.info("CHECKING ENVIRONMENT")
    logger.info("=" * 70)
    
    # Check Python version
    python_version = sys.version_info
    logger.info(f"Python version: {python_version.major}.{python_version.minor}.{python_version.micro}")
    if python_version.major < 3 or (python_version.major == 3 and python_version.minor < 8):
        logger.error("Python 3.8 or higher is required")
        sys.exit(1)
    
    # Check directories
    for directory in [config.DATA_DIR, config.BASELINE_DIR]:
        if not directory.exists():
            logger.error(f"Required directory not found: {directory}")
            sys.exit(1)
        logger.info(f"✓ Directory found: {directory}")
    
    # Check required data files
    required_files = [config.EXTRACTED_CHUNKS, config.TEXT_QNA, config.TABLE_QNA]
    for filepath in required_files:
        check_file_exists(filepath, required=True)
        logger.info(f"✓ Data file found: {filepath.name}")
    
    logger.info("✓ Environment check passed\n")


def install_dependencies() -> None:
    """
    Install required Python packages.
    """
    logger.info("=" * 70)
    logger.info("INSTALLING DEPENDENCIES")
    logger.info("=" * 70)
    
    packages = [
        "transformers",
        "sentence-transformers",
        "torch",
        "chromadb",
        "fastapi",
        "uvicorn",
        "tqdm",
        "requests",
        "bert-score",
        "rouge-score",
        "openai",
        "pydantic",
        "Pillow",
    ]
    
    # Install BARTScore (requires special installation)
    bart_score_packages = [
        "git+https://github.com/neulab/BARTScore.git"
    ]
    
    try:
        logger.info("Installing standard packages...")
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "--upgrade", "pip"
        ])
        subprocess.check_call([
            sys.executable, "-m", "pip", "install"
        ] + packages)
        
        # logger.info("Installing BARTScore...")
        # subprocess.check_call([
        #     sys.executable, "-m", "pip", "install"
        # ] + bart_score_packages)
        
        # logger.info("✓ All dependencies installed successfully\n")
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to install dependencies: {e}")
        logger.error("Please install dependencies manually using: pip install -r requirements.txt")
        sys.exit(1)


def download_models() -> None:
    """
    Download and cache required models locally.
    This ensures all models are available before pipeline execution.
    
    Note: Generation model is ALWAYS downloaded (local generation only).
    Embedding/Reranking models are optional if using API endpoints.
    """
    logger.info("=" * 70)
    logger.info("DOWNLOADING MODELS")
    logger.info("=" * 70)
    
    try:
        #Always download generation model (required for local generation)
        logger.info(f"Downloading generation model: {config.GENERATION_MODEL}")
        logger.info("  (This may take a while for large models...)")
        AutoTokenizer.from_pretrained(config.GENERATION_MODEL)
        # Use AutoModelForCausalLM for generation models
        # from transformers import AutoModelForCausalLM
        # AutoModelForCausalLM.from_pretrained(config.GENERATION_MODEL)
        # logger.info("✓ Generation model downloaded")
        
        # Download embedding/reranking models only if using local models
        if config.USE_LOCAL_MODELS:
            logger.info(f"Downloading embedding model: {config.EMBEDDING_MODEL}")
            SentenceTransformer(config.EMBEDDING_MODEL)
            logger.info("✓ Embedding model downloaded")
            
            logger.info(f"Downloading reranking model: {config.RERANK_MODEL}")
            AutoTokenizer.from_pretrained(config.RERANK_MODEL)
            AutoModelForSequenceClassification.from_pretrained(config.RERANK_MODEL)
            logger.info("✓ Reranking model downloaded")
        else:
            logger.info("Skipping embedding/reranking models (using API endpoints)")
        
        # Download evaluation models (only if not skipping evaluation)
        if not config.SKIP_EVALUATION:
        #     logger.info(f"Downloading BART model: {config.BART_MODEL}")
        #     AutoTokenizer.from_pretrained(config.BART_MODEL)
        #     AutoModel.from_pretrained(config.BART_MODEL)
        #     logger.info("✓ BART model downloaded")
            
            logger.info(f"Downloading BERT model: {config.BERT_MODEL}")
            AutoTokenizer.from_pretrained(config.BERT_MODEL)
            AutoModel.from_pretrained(config.BERT_MODEL)
            logger.info("✓ BERT model downloaded")
        else:
            logger.info("Skipping evaluation models (SKIP_EVALUATION=True)")
        
        logger.info("✓ All required models downloaded successfully\n")
        
    except Exception as e:
        logger.error(f"Failed to download models: {e}")
        logger.warning("You may need to download models manually")
        raise


def validate_config() -> None:
    """
    Validate that all required configuration values are set.
    """
    logger.info("=" * 70)
    logger.info("VALIDATING CONFIGURATION")
    logger.info("=" * 70)
    
    errors = []
    warnings = []
    
    # Check ChromaDB configuration
    if not config.SKIP_CHROMA_UPSERT or not config.SKIP_RETRIEVAL:
        if not config.CHROMA_PERSIST_DIRECTORY:
            errors.append("CHROMA_PERSIST_DIRECTORY is not set")
        # Create ChromaDB directory if it doesn't exist
        Path(config.CHROMA_PERSIST_DIRECTORY).mkdir(parents=True, exist_ok=True)
    
    # Check OpenAI API key for evaluation
    if not config.SKIP_EVALUATION and not config.OPENAI_API_KEY:
        warnings.append("OPENAI_API_KEY is not set - table QnA evaluation will be skipped")
    
    # Display warnings
    if warnings:
        for warning in warnings:
            logger.warning(f"  ⚠ {warning}")
    
    # Display errors and exit if any
    if errors:
        logger.error("Configuration validation failed:")
        for error in errors:
            logger.error(f"  ✗ {error}")
        logger.error("\nPlease update the PipelineConfig class in this script with your credentials.")
        logger.error("Or set the appropriate SKIP_* flags if you want to skip certain steps.")
        sys.exit(1)
    
    logger.info("✓ Configuration validated")
    logger.info(f"  - Using local models (embed/rerank): {config.USE_LOCAL_MODELS}")
    logger.info(f"  - Using local generation: Always (required)")
    logger.info(f"  - ChromaDB directory: {config.CHROMA_PERSIST_DIRECTORY}")
    logger.info(f"  - Skip ChromaDB upsert: {config.SKIP_CHROMA_UPSERT}")
    logger.info(f"  - Skip retrieval: {config.SKIP_RETRIEVAL}")
    logger.info(f"  - Skip generation: {config.SKIP_GENERATION}")
    logger.info(f"  - Skip evaluation: {config.SKIP_EVALUATION}")
    logger.info(f"  - Force regenerate: {config.FORCE_REGENERATE}")
    logger.info("")


# ============================================================================
# PIPELINE STAGES
# ============================================================================

def stage_1_chroma_upsert() -> None:
    """
    Stage 1: Ingest chunks into ChromaDB vector database.
    
    This stage:
    - Loads extracted chunks from JSON
    - Generates embeddings for each chunk
    - Uploads vectors to ChromaDB with metadata
    """
    if config.SKIP_CHROMA_UPSERT:
        logger.info("Skipping Stage 1: ChromaDB Upsert (SKIP_CHROMA_UPSERT=True)")
        return
    
    logger.info("=" * 70)
    logger.info("STAGE 1: CHROMADB UPSERT (INGESTION)")
    logger.info("=" * 70)
    
    try:
        import uuid
        from tqdm import tqdm
        import chromadb
        from chromadb.config import Settings
        
        # Initialize ChromaDB client
        logger.info(f"Initializing ChromaDB client at {config.CHROMA_PERSIST_DIRECTORY}...")
        chroma_client = chromadb.PersistentClient(
            path=config.CHROMA_PERSIST_DIRECTORY,
            settings=Settings(anonymized_telemetry=False)
        )
        
        # Load chunks
        chunks = load_json(config.EXTRACTED_CHUNKS)
        logger.info(f"Loaded {len(chunks)} chunk groups")
        
        # Setup embedding function
        from sentence_transformers import SentenceTransformer
        embedding_model = SentenceTransformer(config.EMBEDDING_MODEL, device=config.DEVICE)
        
        def get_embeddings(texts):
            return embedding_model.encode(texts, convert_to_tensor=False).tolist()
    
        # Process each document's chunks
        logger.info("Upserting chunks to ChromaDB...")
        
        # Get or create collection
        try:
            collection = chroma_client.get_collection(name=config.CHROMA_COLLECTION_NAME)
            logger.info(f"Collection '{config.CHROMA_COLLECTION_NAME}' already exists with {collection.count()} items")
            
            # Optionally, clear the collection if force regenerate
            if config.FORCE_REGENERATE:
                logger.info("Force regenerate enabled, deleting existing collection...")
                chroma_client.delete_collection(name=config.CHROMA_COLLECTION_NAME)
                collection = chroma_client.create_collection(
                    name=config.CHROMA_COLLECTION_NAME,
                    metadata={"hnsw:space": "cosine"}
                )
                logger.info(f"✓ Collection '{config.CHROMA_COLLECTION_NAME}' recreated")
        except Exception:
            logger.info(f"Collection '{config.CHROMA_COLLECTION_NAME}' not found, creating new collection...")
            collection = chroma_client.create_collection(
                name=config.CHROMA_COLLECTION_NAME,
                metadata={"hnsw:space": "cosine"}
            )
            logger.info(f"✓ Collection '{config.CHROMA_COLLECTION_NAME}' created successfully")

        for entry in tqdm(chunks, desc="Processing documents"):
            try:
                texts = [chunk['text'] for chunk in entry['chunks']]
                
                # Generate embeddings
                embeddings = get_embeddings(texts)
                
                if embeddings:
                    # Prepare metadata
                    metadatas = []
                    for chunk in entry['chunks']:
                        metadatas.append({
                            "filename": entry['filename'],
                            "text": chunk['text']
                        })
                    
                    # Generate unique IDs
                    ids = [str(uuid.uuid4()) for _ in range(len(texts))]
                    
                    # Upsert to ChromaDB (add documents with embeddings)
                    collection.add(
                        ids=ids,
                        embeddings=embeddings,
                        metadatas=metadatas,
                        documents=texts
                    )
            except Exception as e:
                logger.error(f"Error processing {entry.get('filename', 'unknown')}: {e}")
        
        total_count = collection.count()
        logger.info(f"✓ Stage 1 completed: {total_count} chunks uploaded to ChromaDB\n")
        
    except Exception as e:
        logger.error(f"Stage 1 failed: {e}")
        import traceback
        logger.error(traceback.format_exc())
        sys.exit(1)


def stage_2_retrieval_and_rerank() -> None:
    """
    Stage 2: Retrieve and rerank chunks for each question.
    
    This stage:
    - Loads QnA pairs
    - For each question, retrieves top-K chunks from Qdrant
    - Reranks the retrieved chunks
    - Saves the top reranked chunks
    
    Output files generated:
    - text_qna_retrieved.json
    - table_qna_retrieved.json
    """
    if config.SKIP_RETRIEVAL:
        logger.info("Skipping Stage 2: Retrieval and Rerank (SKIP_RETRIEVAL=True)")
        return
    
    # Check if output files already exist
    if not config.FORCE_REGENERATE:
        if config.TEXT_QNA_RETRIEVED.exists() and config.TABLE_QNA_RETRIEVED.exists():
            logger.info("Stage 2 output files already exist. Set FORCE_REGENERATE=True to regenerate.")
            logger.info(f"  - {config.TEXT_QNA_RETRIEVED.name}")
            logger.info(f"  - {config.TABLE_QNA_RETRIEVED.name}")
            return
    
    logger.info("=" * 70)
    logger.info("STAGE 2: RETRIEVAL AND RERANKING")
    logger.info("=" * 70)
    
    # Process both text and table QnA
    for qna_type, input_file, output_file in [
        ("Text", config.TEXT_QNA, config.TEXT_QNA_RETRIEVED),
        ("Table", config.TABLE_QNA, config.TABLE_QNA_RETRIEVED)
    ]:
        try:
            from tqdm import tqdm
            import chromadb
            from chromadb.config import Settings
            
            logger.info(f"\nProcessing {qna_type} QnA...")
            
            # Initialize ChromaDB client
            chroma_client = chromadb.PersistentClient(
                path=config.CHROMA_PERSIST_DIRECTORY,
                settings=Settings(anonymized_telemetry=False)
            )
            
            # Get collection
            collection = chroma_client.get_collection(name=config.CHROMA_COLLECTION_NAME)
            
            # Load QnA data
            qna_data = load_json(input_file)
            logger.info(f"Loaded {len(qna_data)} questions")
            
            # Setup embedding and reranking functions
            from sentence_transformers import SentenceTransformer
            from transformers import AutoTokenizer, AutoModelForSequenceClassification
            import torch
            
            embedding_model = SentenceTransformer(config.EMBEDDING_MODEL, device=config.DEVICE)
            rerank_tokenizer = AutoTokenizer.from_pretrained(config.RERANK_MODEL)
            rerank_model = AutoModelForSequenceClassification.from_pretrained(
                config.RERANK_MODEL
            ).to(config.DEVICE)
            rerank_model.eval()
            
            def get_query_embedding(query):
                return embedding_model.encode([query], convert_to_tensor=False)[0].tolist()
            
            def rerank_docs(query, docs):
                inputs = rerank_tokenizer(
                    [f"{query} [SEP] {doc}" for doc in docs],
                    padding=True,
                    truncation=True,
                    return_tensors="pt"
                ).to(config.DEVICE)
                
                with torch.no_grad():
                    outputs = rerank_model(**inputs)
                    scores = torch.sigmoid(outputs.logits).squeeze(-1)
                
                ranked = sorted(
                    zip(docs, scores.tolist()),
                    key=lambda x: x[1],
                    reverse=True
                )
                return [{"text": text, "score": score} for text, score in ranked]
        
            # Process each question
            for entry in tqdm(qna_data, desc=f"Processing {qna_type} QnA"):
                try:
                    query = entry['question']
                    
                    # Get query embedding
                    query_vector = get_query_embedding(query)
                    
                    # Retrieve top-K chunks from ChromaDB
                    ranking_results = collection.query(
                        query_embeddings=[query_vector],
                        n_results=config.RETRIEVAL_TOP_K,
                        include=["documents", "metadatas", "distances"]
                    )
                    
                    # Extract texts and metadatas for reranking
                    rerank_input = ranking_results['documents'][0]  # First query's results
                    result_metadatas = ranking_results['metadatas'][0]
                    
                    # Rerank the retrieved chunks
                    rerank_response = rerank_docs(query, rerank_input)
                    
                    # Get top-K after reranking
                    retrieval_output = []
                    for res in rerank_response[:config.RERANK_TOP_K]:
                        text = res["text"]
                        score = res["score"]
                        
                        # Find the corresponding file from original results
                        for idx, doc_text in enumerate(rerank_input):
                            if text == doc_text:
                                retrieval_output.append({
                                    'text': text,
                                    'file': result_metadatas[idx]['filename'],
                                    'score': score
                                })
                                break
                    
                    entry['retrieval_output'] = retrieval_output
                    
                except Exception as e:
                    logger.error(f"Error processing question '{entry.get('question', '')}': {e}")
                    entry['retrieval_output'] = []
            
            # Save results
            save_json(qna_data, output_file)
            logger.info(f"✓ {qna_type} QnA retrieval completed")
            
        except Exception as e:
            logger.error(f"Failed to process {qna_type} QnA: {e}")
            import traceback
            logger.error(traceback.format_exc())
    
    logger.info("\n✓ Stage 2 completed: Retrieval and reranking finished\n")


def stage_3_llm_generation() -> None:
    """
    Stage 3: Generate answers using LLM based on retrieved chunks.
    
    This stage:
    - Loads retrieved QnA with chunks
    - Creates prompts with context and question
    - Calls LLM to generate answers (API or local model)
    - Saves generated answers
    
    Output files generated:
    - text_qna_generated_llama.json
    - table_qna_generated_llama.json
    """
    if config.SKIP_GENERATION:
        logger.info("Skipping Stage 3: LLM Generation (SKIP_GENERATION=True)")
        return
    
    # Check if output files already exist
    if not config.FORCE_REGENERATE:
        if config.TEXT_QNA_GENERATED.exists() and config.TABLE_QNA_GENERATED.exists():
            logger.info("Stage 3 output files already exist. Set FORCE_REGENERATE=True to regenerate.")
            logger.info(f"  - {config.TEXT_QNA_GENERATED.name}")
            logger.info(f"  - {config.TABLE_QNA_GENERATED.name}")
            return
    
    logger.info("=" * 70)
    logger.info("STAGE 3: LLM GENERATION")
    logger.info("=" * 70)
    
    # Import prompts
    sys.path.insert(0, str(config.BASELINE_DIR))
    from baseline.prompts import OLD_PROMPT_V2
    
    # Load local generation model (always used)
    logger.info("Loading local generation model...")
    logger.info(f"  Model: {config.GENERATION_MODEL}")
    logger.info(f"  Device: {config.DEVICE}")
    
    import torch
    # from transformers import AutoTokenizer, AutoModelForCausalLM
    
    # tokenizer = AutoTokenizer.from_pretrained(config.GENERATION_MODEL)
    
    # Set padding token if not set
    # if tokenizer.pad_token is None:
    #     tokenizer.pad_token = tokenizer.eos_token
    
    logger.info("  Loading model weights (this may take a few minutes)...")
    # model = AutoModelForCausalLM.from_pretrained(
    #     config.GENERATION_MODEL,
    #     torch_dtype=torch.float16 if config.DEVICE == "cuda" else torch.float32,
    #     device_map="auto" if config.DEVICE == "cuda" else None,
    #     low_cpu_mem_usage=True
    # )
    
    if config.DEVICE == "cpu":
        model = model.to("cpu")
    
    model.eval()
    logger.info("✓ Local generation model loaded successfully")
    
    def generate_answer(prompt: str) -> str:
        """Generate answer using local LLM."""
        # Prepare inputs
        inputs = tokenizer(
            prompt, 
            return_tensors="pt", 
            truncation=True, 
            max_length=4096,
            padding=True
        )
        inputs = {k: v.to(model.device) for k, v in inputs.items()}
        
        # Generate
        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=512,
                temperature=0.7,
                do_sample=True,
                top_p=0.9,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id
            )
        
        # Decode and extract answer
        generated_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extract only the answer part (remove the prompt)
        if generated_text.startswith(prompt):
            answer = generated_text[len(prompt):].strip()
        else:
            # If prompt isn't at the start, try to find where the answer begins
            answer = generated_text.strip()
        
        return answer if answer else "Unable to generate answer."
    
    # Process both text and table QnA
    for qna_type, input_file, output_file in [
        ("Text", config.TEXT_QNA_RETRIEVED, config.TEXT_QNA_GENERATED),
        ("Table", config.TABLE_QNA_RETRIEVED, config.TABLE_QNA_GENERATED)
    ]:
        try:
            from tqdm import tqdm
            
            logger.info(f"\nProcessing {qna_type} QnA...")
            
            # Check if input file exists
            if not input_file.exists():
                logger.warning(f"Input file not found: {input_file}")
                logger.warning(f"Skipping {qna_type} QnA generation")
                continue
            
            # Load QnA data with retrieval results
            qna_data = load_json(input_file)
            logger.info(f"Loaded {len(qna_data)} questions")
            
            def create_prompt(contexts: List[str], question: str) -> str:
                """Create prompt with context and question."""
                prompt = OLD_PROMPT_V2 + "Contexts:\n"
                prompt += "\n".join([f"{i+1}. {c}" for i, c in enumerate(contexts)])
                prompt += f"\n\nQuestion: {question}"
                return prompt
            
            # Process each question
            for entry in tqdm(qna_data, desc=f"Generating {qna_type} answers"):
                try:
                    question = entry['question']
                    top_chunks = [chunk['text'] for chunk in entry.get('retrieval_output', [])]
                    
                    if not top_chunks:
                        logger.warning(f"No retrieved chunks for question: {question}")
                        entry['generated'] = "Unable to answer due to lack of context."
                        continue
                    
                    # Create prompt
                    query = create_prompt(top_chunks, question)
                    
                    # Generate answer (using local model or API)
                    generated_answer = generate_answer(query)
                    entry['generated'] = generated_answer
                    
                except Exception as e:
                    logger.error(f"Error generating answer for '{entry.get('question', '')}': {e}")
                    entry['generated'] = "Generation error."
            
            # Save results
            save_json(qna_data, output_file)
            logger.info(f"✓ {qna_type} QnA generation completed")
            
        except Exception as e:
            logger.error(f"Failed to generate {qna_type} QnA: {e}")
            import traceback
            logger.error(traceback.format_exc())
    
    logger.info("\n✓ Stage 3 completed: Answer generation finished\n")


def stage_4_evaluation() -> None:
    """
    Stage 4: Evaluate generated answers using multiple metrics.
    
    This stage:
    - Computes ROUGE scores (R1, R2, RL)
    - Computes BERT F1 scores
    - Computes BART F1 scores
    - Saves scored results
    
    Output files generated:
    - text_qna_generated_llama_scored.json
    - table_qna_generated_llama_scored.json
    """
    if config.SKIP_EVALUATION:
        logger.info("Skipping Stage 4: Evaluation (SKIP_EVALUATION=True)")
        return
    
    # Check if output files already exist
    if not config.FORCE_REGENERATE:
        if config.TEXT_QNA_SCORED.exists() and config.TABLE_QNA_SCORED.exists():
            logger.info("Stage 4 output files already exist. Set FORCE_REGENERATE=True to regenerate.")
            logger.info(f"  - {config.TEXT_QNA_SCORED.name}")
            logger.info(f"  - {config.TABLE_QNA_SCORED.name}")
            return
    
    logger.info("=" * 70)
    logger.info("STAGE 4: EVALUATION (ROUGE, BERT, BART)")
    logger.info("=" * 70)
    
    try:
        from tqdm import tqdm
        from BARTScore.bart_score import BARTScorer
        from bert_score import score
        from rouge_score import rouge_scorer
        
        def bart_f1(cands, refs, device=config.DEVICE, checkpoint=config.BART_MODEL):
            """Compute BARTScore F1."""
            if isinstance(cands, str):
                cands = [cands]
            if isinstance(refs, str):
                refs = [refs]
            
            scorer = BARTScorer(device=device, checkpoint=checkpoint)
            P = scorer.score(cands, refs, batch_size=4)
            R = scorer.score(refs, cands, batch_size=4)
            F1 = [(2*p*r)/(p+r) if (p+r) else 0.0 for p, r in zip(P, R)]
            return [P[0], R[0], F1[0]]
        
        def bert_f1(cands, refs, model_type=config.BERT_MODEL):
            """Compute BERTScore F1."""
            if isinstance(cands, str):
                cands = [cands]
            if isinstance(refs, str):
                refs = [refs]
            
            P, R, F1 = score(
                cands, refs,
                model_type=model_type,
                lang="en",
                verbose=False,
                rescale_with_baseline=True
            )
            return [P.tolist()[0], R.tolist()[0], F1.tolist()[0]]
        
        def compute_rouge(cands, refs):
            """Compute ROUGE scores."""
            if isinstance(cands, str):
                cands = [cands]
            if isinstance(refs, str):
                refs = [refs]
            
            scorer = rouge_scorer.RougeScorer(
                ["rouge1", "rouge2", "rougeL"], use_stemmer=True
            )
            scores = scorer.score(refs[0], cands[0])
            return {
                k: {"p": v.precision, "r": v.recall, "f": v.fmeasure}
                for k, v in scores.items()
            }
        
        def score_instance(hypo, ref):
            """Score a single hypothesis against reference."""
            bart_score = bart_f1(hypo, ref)
            bert_score = bert_f1(hypo, ref)
            rouge = compute_rouge(hypo, ref)
            
            return {
                'bart_f1': bart_score,
                'bert_f1': bert_score,
                'r1': rouge['rouge1'],
                'r2': rouge['rouge2'],
                'rL': rouge['rougeL']
            }
        
        # Process both text and table QnA
        for qna_type, input_file, output_file in [
            ("Text", config.TEXT_QNA_GENERATED, config.TEXT_QNA_SCORED),
            ("Table", config.TABLE_QNA_GENERATED, config.TABLE_QNA_SCORED)
        ]:
            try:
                logger.info(f"\nEvaluating {qna_type} QnA...")
                
                # Check if input file exists
                if not input_file.exists():
                    logger.warning(f"Input file not found: {input_file}")
                    logger.warning(f"Skipping {qna_type} QnA evaluation")
                    continue
                
                # Load generated QnA
                data = load_json(input_file)
                logger.info(f"Loaded {len(data)} generated answers")
                
                # Score each entry
                for entry in tqdm(data, desc=f"Scoring {qna_type} QnA"):
                    try:
                        automatic_scores = score_instance(
                            hypo=entry.get('generated', ''),
                            ref=entry.get('answer', '')
                        )
                        entry['automatic_scores'] = automatic_scores
                    except Exception as e:
                        logger.error(f"Error scoring entry: {e}")
                        entry['automatic_scores'] = None
                
                # Save scored results
                save_json(data, output_file)
                logger.info(f"✓ {qna_type} QnA evaluation completed")
                
            except Exception as e:
                logger.error(f"Failed to evaluate {qna_type} QnA: {e}")
                import traceback
                logger.error(traceback.format_exc())
        
        logger.info("\n✓ Stage 4 completed: Evaluation finished\n")
        
    except Exception as e:
        logger.error(f"Stage 4 failed: {e}")
        import traceback
        logger.error(traceback.format_exc())


def stage_5_compute_averages() -> None:
    """
    Stage 5: Compute average scores across all questions.
    
    This stage:
    - Loads scored results
    - Computes mean precision, recall, F1 for each metric
    - Displays results in a formatted table
    """
    logger.info("=" * 70)
    logger.info("STAGE 5: COMPUTE AVERAGE SCORES")
    logger.info("=" * 70)
    
    try:
        from statistics import mean
        
        def f1_score(p, r):
            """Compute F1 from precision and recall."""
            if p + r == 0:
                return 0.0
            return 2 * p * r / (p + r)
        
        def compute_averages(data):
            """Compute average scores from scored data."""
            bart_p, bart_r, bart_f = [], [], []
            bert_p, bert_r, bert_f = [], [], []
            r1_p, r1_r, r1_f = [], [], []
            r2_p, r2_r, r2_f = [], [], []
            rL_p, rL_r, rL_f = [], [], []
            
            for item in data:
                scores = item.get("automatic_scores")
                if not scores:
                    continue
                
                # BART scores
                bart_p.append(scores["bart_f1"][0])
                bart_r.append(scores["bart_f1"][1])
                bart_f.append(scores["bart_f1"][2])
                
                # BERT scores
                bert_p.append(scores["bert_f1"][0])
                bert_r.append(scores["bert_f1"][1])
                bert_f.append(scores["bert_f1"][2])
                
                # ROUGE scores
                r1_p.append(scores["r1"]["p"])
                r1_r.append(scores["r1"]["r"])
                r1_f.append(scores["r1"]["f"])
                
                r2_p.append(scores["r2"]["p"])
                r2_r.append(scores["r2"]["r"])
                r2_f.append(scores["r2"]["f"])
                
                rL_p.append(scores["rL"]["p"])
                rL_r.append(scores["rL"]["r"])
                rL_f.append(scores["rL"]["f"])
            
            if not bart_p:  # No valid scores
                return None
            
            return {
                "bart_f1": {
                    "p": mean(bart_p), "r": mean(bart_r),
                    "f": mean(bart_f), "f_": f1_score(mean(bart_p), mean(bart_r))
                },
                "bert_f1": {
                    "p": mean(bert_p), "r": mean(bert_r),
                    "f": mean(bert_f), "f_": f1_score(mean(bert_p), mean(bert_r))
                },
                "r1": {
                    "p": mean(r1_p), "r": mean(r1_r),
                    "f": mean(r1_f), "f_": f1_score(mean(r1_p), mean(r1_r))
                },
                "r2": {
                    "p": mean(r2_p), "r": mean(r2_r),
                    "f": mean(r2_f), "f_": f1_score(mean(r2_p), mean(r2_r))
                },
                "rL": {
                    "p": mean(rL_p), "r": mean(rL_r),
                    "f": mean(rL_f), "f_": f1_score(mean(rL_p), mean(rL_r))
                }
            }
        
        def print_averages(title, averages):
            """Print averages in formatted table."""
            if not averages:
                logger.warning(f"No valid scores to display for {title}")
                return
            
            print(f"\n{title}")
            print("-" * 55)
            print("{:<10} {:>10} {:>10} {:>10} {:>10}".format(
                "Metric", "P", "R", "F(avg)", "F(hm)"
            ))
            print("-" * 55)
            for metric, scores in averages.items():
                print("{:<10} {:>10.4f} {:>10.4f} {:>10.4f} {:>10.4f}".format(
                    metric, scores["p"], scores["r"], scores["f"], scores["f_"]
                ))
            print("-" * 55)
        
        def save_averages(title, averages, filepath):
            """Save averages to a JSON file."""
            if not averages:
                logger.warning(f"No valid scores to save for {title}")
                return
            
            output_data = {
                "title": title,
                "averages": averages
            }
            save_json([output_data], filepath)
            logger.info(f"Saved averages for {title} to {filepath}")
        
        # Compute and display averages for both text and table QnA
        for qna_type, scored_file in [
            ("TEXT QnA", config.TEXT_QNA_SCORED),
            ("TABLE QnA", config.TABLE_QNA_SCORED)
        ]:
            if scored_file.exists():
                data = load_json(scored_file)
                averages = compute_averages(data)
                print_averages(qna_type, averages)
                
                # Save averages to file
                averages_file = scored_file.parent / f"{scored_file.stem}_averages.json"
                save_averages(qna_type, averages, averages_file)
            else:
                logger.warning(f"Scored file not found: {scored_file}")
        
        logger.info("\n✓ Stage 5 completed: Average scores computed\n")
        
    except Exception as e:
        logger.error(f"Stage 5 failed: {e}")
        import traceback
        logger.error(traceback.format_exc())


def stage_6_table_qna_evaluation() -> None:
    """
    Stage 6: Evaluate table QnA with OpenAI for accuracy and source validation.
    
    This stage:
    - Uses OpenAI API to evaluate if generated answers are correct
    - Determines if answer came from table or text chunks
    - Computes recall and precision metrics
    
    Output files generated:
    - table_qna_generated_llama_scored_evaluated.json
    """
    if config.SKIP_EVALUATION:
        logger.info("Skipping Stage 6: Table QnA Evaluation (SKIP_EVALUATION=True)")
        return
    
    if not config.OPENAI_API_KEY:
        logger.warning("OpenAI API key not set. Skipping table QnA evaluation.")
        return
    
    # Check if output file already exists
    if not config.FORCE_REGENERATE:
        if config.TABLE_QNA_EVALUATED.exists():
            logger.info("Stage 6 output file already exists. Set FORCE_REGENERATE=True to regenerate.")
            logger.info(f"  - {config.TABLE_QNA_EVALUATED.name}")
            return
    
    logger.info("=" * 70)
    logger.info("STAGE 6: TABLE QnA EVALUATION (ACCURACY & SOURCE)")
    logger.info("=" * 70)
    
    try:
        from concurrent.futures import ThreadPoolExecutor, as_completed
        from tqdm import tqdm
        from openai import OpenAI
        from pydantic import BaseModel, Field
        from typing import Literal
        
        # Setup OpenAI client
        client = OpenAI(api_key=config.OPENAI_API_KEY)
        
        # Load required data
        extracted_chunks = load_json(config.EXTRACTED_CHUNKS)
        
        if not config.TABLE_QNA_SCORED.exists():
            logger.warning(f"Scored file not found: {config.TABLE_QNA_SCORED}")
            logger.warning("Skipping table QnA evaluation")
            return
        
        table_qna = load_json(config.TABLE_QNA_SCORED)
        
        # Define evaluation output schema
        class RAGEvalOutput(BaseModel):
            result: Literal['correct', 'wrong'] = Field(
                ..., description="Whether generated answer is factually correct."
            )
            source: Literal['text', 'table', 'both', 'none'] = Field(
                ..., description="Which chunk set independently supports the answer."
            )
        
        EVAL_PROMPT = '''You are an evaluator. Inputs:
- QUESTION: {question}
- GROUND TRUTH: {ground_truth}
- GENERATED ANSWER: {generated_answer}
- TABLE CHUNKS: ### {table_chunks} ###
- TEXT CHUNKS: ### {text_chunks} ###

Task (strict rules):
1. Extract the factual main answer-phrase from the GROUND_TRUTH — the concise factual claim that answers the QUESTION.
2. Decide if the GENERATED_ANSWER conveys the same factual claim. If it matches, set result = "correct". Otherwise set result = "wrong".
3. If and only if result == "correct", determine source (text/table/both/none) based on which chunks support the answer.
4. Output exactly one dictionary (JSON-like) with the two keys only: result and source.

Do not add any extra text, explanations, or fields. Evaluate conservatively: prefer wrong if uncertain.
'''
        
        def process_entry(idx, entry):
            """Process a single QnA entry for evaluation."""
            question = entry['question']
            table = entry.get('table', '')
            ground_truth = entry.get('answer', '')
            generated_answer = entry.get('generated', '')
            retrieved_chunks = [i['text'] for i in entry.get('retrieval_output', [])]
            
            retrieved_text_chunks = []
            retrieved_table_chunks = []
            
            for retrieved_chunk in retrieved_chunks:
                for file_chunks in extracted_chunks:
                    for chunk in file_chunks['chunks']:
                        if chunk['text'] == retrieved_chunk and chunk.get('parsed_table'):
                            retrieved_table_chunks.append(chunk)
                        elif chunk['text'] == retrieved_chunk:
                            retrieved_text_chunks.append(chunk)
            
            user_message = EVAL_PROMPT.format(
                question=question,
                ground_truth=ground_truth,
                generated_answer=generated_answer,
                table_chunks=table,
                text_chunks=retrieved_text_chunks,
            )
            
            # Call OpenAI API
            response = client.responses.parse(
                model="gpt-4o-2024-08-06",
                input=[
                    {
                        "role": "system",
                        "content": "Evaluate the QnA results below as instructed and return the response in JSON format."
                    },
                    {
                        "role": "user",
                        "content": user_message,
                    },
                ],
                text_format=RAGEvalOutput,
            )
            
            event = response.output_parsed
            return idx, event.result, event.source
        
        # Process entries in parallel
        logger.info("Evaluating table QnA with OpenAI...")
        futures = []
        with ThreadPoolExecutor(max_workers=3) as exe:
            for i, entry in enumerate(table_qna):
                futures.append(exe.submit(process_entry, i, entry))
            
            for future in tqdm(as_completed(futures), total=len(futures), desc="Evaluating"):
                try:
                    idx, result, source = future.result()
                    table_qna[idx]['evaluation'] = result
                    table_qna[idx]['source'] = source
                except Exception as e:
                    logger.error(f"Task failed with: {e}")
        
        # Save evaluated results
        save_json(table_qna, config.TABLE_QNA_EVALUATED)
        
        # Compute metrics
        logger.info("\nComputing accuracy and retrieval metrics...")
        
        accuracies = []
        table_recalls_at_k = []
        table_precisions_at_1 = []
        
        for qa in table_qna:
            if qa.get("source") != "table":
                continue
            
            accuracies.append(qa.get('evaluation', 'wrong'))
            
            # Compute recall and precision metrics
            q_file = qa.get('filename', '')
            a_table = qa.get('table', '')
            retrieved_chunks = [i['text'] for i in qa.get('retrieval_output', [])]
            
            retrieved_table_chunks = []
            for retrieved_chunk in retrieved_chunks:
                for file_chunks in extracted_chunks:
                    for chunk in file_chunks['chunks']:
                        if chunk['text'] == retrieved_chunk and chunk.get('parsed_table'):
                            retrieved_table_chunks.append(chunk)
            
            a_table_chunks = []
            for file_chunks in extracted_chunks:
                if file_chunks['filename'] == q_file:
                    for chunk in file_chunks['chunks']:
                        if chunk.get('parsed_table') and a_table in chunk['parsed_table']:
                            a_table_chunks.append(chunk['text'])
            
            # Recall: did we retrieve the correct table chunk?
            table_recall = 0
            for retrieved_table_chunk in retrieved_table_chunks:
                if retrieved_table_chunk['text'] in a_table_chunks:
                    table_recall = 1
                    break
            table_recalls_at_k.append(table_recall)
            
            # Precision: is the first table chunk correct?
            table_precision = 0
            if retrieved_table_chunks and retrieved_table_chunks[0]['text'] in a_table_chunks:
                table_precision = 1
            table_precisions_at_1.append(table_precision)
        
        # Display metrics
        if accuracies:
            accuracy = accuracies.count('correct') / len(accuracies)
            logger.info(f"\nTable QnA Accuracy: {accuracy:.4f}")
        
        if table_recalls_at_k:
            table_recall = sum(table_recalls_at_k) / len(table_recalls_at_k)
            logger.info(f"Table Recall @ {config.RERANK_TOP_K}: {table_recall:.4f}")
        
        if table_precisions_at_1:
            table_precision = sum(table_precisions_at_1) / len(table_precisions_at_1)
            logger.info(f"Table Precision @ 1: {table_precision:.4f}")
        
        logger.info("\n✓ Stage 6 completed: Table QnA evaluation finished\n")
        
    except Exception as e:
        logger.error(f"Stage 6 failed: {e}")
        import traceback
        logger.error(traceback.format_exc())


# ============================================================================
# MAIN PIPELINE
# ============================================================================

def main():
    """
    Main pipeline execution function.
    
    Orchestrates all stages of the RAG pipeline:
    1. Environment check - Verify Python version, directories, and data files
    2. Dependency installation - Install required Python packages
    3. Model downloads - Download all required models (always includes generation model)
    4. Configuration validation - Verify all required settings are configured
    5. ChromaDB upsert (ingestion) - Upload chunks to vector database
    6. Retrieval and reranking - Find relevant chunks for each question
    7. LLM generation - Generate answers using local LLM (always local, never API)
    8. Evaluation - Score answers with ROUGE, BERT, BART metrics
    9. Compute averages - Aggregate scores and display results
    10. Table QnA evaluation - Evaluate table-based answers with OpenAI
    
    Output files generated by each stage:
    - Stage 2: text_qna_retrieved.json, table_qna_retrieved.json
    - Stage 3: text_qna_generated_llama.json, table_qna_generated_llama.json
    - Stage 4: text_qna_generated_llama_scored.json, table_qna_generated_llama_scored.json
    - Stage 6: table_qna_generated_llama_scored_evaluated.json
    
    Control behavior with configuration flags:
    - SKIP_* flags to skip stages
    - FORCE_REGENERATE to regenerate existing output files
    - USE_LOCAL_MODELS for embedding/reranking (generation is always local)
    """
    logger.info("\n")
    logger.info("=" * 70)
    logger.info("HPC-RAG PIPELINE EXECUTION")
    logger.info("=" * 70)
    logger.info("\n")
    
    try:
        # Pre-flight checks
        check_environment()
        install_dependencies()
        download_models()
        validate_config()
        
        # Execute pipeline stages
        stage_1_chroma_upsert()
        stage_2_retrieval_and_rerank()
        stage_3_llm_generation()
        stage_4_evaluation()
        stage_5_compute_averages()
        stage_6_table_qna_evaluation()
        
        # Pipeline completed
        logger.info("=" * 70)
        logger.info("PIPELINE EXECUTION COMPLETED SUCCESSFULLY")
        logger.info("=" * 70)
        logger.info("\nAll stages completed. Check the data/ directory for output files.")
        logger.info("Logs saved to: pipeline_execution.log")
        
    except KeyboardInterrupt:
        logger.warning("\n\nPipeline interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"\n\nPipeline failed with error: {e}")
        import traceback
        logger.error(traceback.format_exc())
        sys.exit(1)


if __name__ == "__main__":
    main()

